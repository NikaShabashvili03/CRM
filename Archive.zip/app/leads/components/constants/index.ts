export const BOARD_SECTIONS: any = {
    new: "New",
    offer: "The offer is made",
    negotiations: "Negotiations are underway",
    reserved: "Is reserved",
    contract: "The contract is signed"
  };