import React from 'react'

export default function DashboardClient() {
  return (
    <div>
        123123123
    </div>
  )
}
