import Image from 'next/image'
import DashboardClient from './DashboardClient'

export default function Home() {
  return (
    <>
      <DashboardClient/>
    </>
  )
}
